from typing import List, Optional, Dict, Any
from langchain.vectorstores import VectorStore
from langchain.embeddings.base import Embeddings
from langchain.schema import Document
from langchain.retrievers import BaseRetriever

class RAGService:
    """检索增强生成服务"""
    
    def __init__(self, vector_store: VectorStore, embeddings: Embeddings):
        self.vector_store = vector_store
        self.embeddings = embeddings
        
    async def retrieve_relevant_documents(self, query: str, top_k: int = 3) -> List[Document]:
        """检索与查询相关的文档"""
        return self.vector_store.similarity_search(query, k=top_k)
    
    def get_retriever(self, search_kwargs: Optional[Dict[str, Any]] = None) -> BaseRetriever:
        """获取检索器实例"""
        search_kwargs = search_kwargs or {"k": 3}
        return self.vector_store.as_retriever(search_kwargs=search_kwargs)
    
    async def add_documents(self, documents: List[Document]) -> None:
        """添加新文档到向量存储"""
        self.vector_store.add_documents(documents)
    
    async def delete_documents(self, document_ids: List[str]) -> None:
        """从向量存储中删除文档"""
        # 注意：具体实现取决于使用的向量存储类型
        if hasattr(self.vector_store, "delete"):
            self.vector_store.delete(document_ids)
    
    async def query_with_metadata_filter(self, query: str, filter_dict: Dict[str, Any], top_k: int = 3) -> List[Document]:
        """使用元数据过滤器进行查询"""
        return self.vector_store.similarity_search(
            query, 
            k=top_k, 
            filter=filter_dict
        )
