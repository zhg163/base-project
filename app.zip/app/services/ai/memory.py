from typing import Dict, List, Optional
from langchain.memory import ConversationBufferMemory, ConversationSummaryMemory
from langchain.schema import BaseMemory

class MemoryManager:
    """管理对话记忆"""
    
    def __init__(self, memory_type: str = "buffer", max_token_limit: int = 2000):
        self.memory_type = memory_type
        self.max_token_limit = max_token_limit
        self.memory = self._initialize_memory()
        
    def _initialize_memory(self) -> BaseMemory:
        """初始化记忆组件"""
        if self.memory_type == "buffer":
            return ConversationBufferMemory(
                memory_key="chat_history",
                return_messages=True
            )
        elif self.memory_type == "summary":
            return ConversationSummaryMemory(
                memory_key="chat_history",
                return_messages=True,
                max_token_limit=self.max_token_limit
            )
        else:
            raise ValueError(f"Unsupported memory type: {self.memory_type}")
    
    def add_user_message(self, message: str) -> None:
        """添加用户消息到记忆"""
        self.memory.chat_memory.add_user_message(message)
    
    def add_ai_message(self, message: str) -> None:
        """添加AI消息到记忆"""
        self.memory.chat_memory.add_ai_message(message)
    
    def get_conversation_history(self) -> List[Dict]:
        """获取对话历史"""
        return self.memory.load_memory_variables({})["chat_history"]
    
    def clear(self) -> None:
        """清除记忆"""
        self.memory.clear() 