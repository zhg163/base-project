from typing import Dict, List, Optional, Union, Any
from langchain.chains import LLMChain
from langchain.chat_models import ChatOpenAI
from langchain.llms.base import BaseLLM
from langchain.schema import BaseMemory, AIMessage, HumanMessage
import asyncio
from fastapi import BackgroundTasks
from sse_starlette.sse import EventSourceResponse

class ModelRegistry:
    """模型注册表，管理所有可用的LLM模型"""
    
    def __init__(self):
        self.models: Dict[str, BaseLLM] = {}
        
    def register_model(self, model_id: str, model: BaseLLM) -> None:
        self.models[model_id] = model
        
    def get_model(self, model_id: str) -> BaseLLM:
        if model_id not in self.models:
            raise ValueError(f"Model {model_id} not registered")
        return self.models[model_id]
        
    def list_models(self) -> List[str]:
        return list(self.models.keys())


class ResponseHandler:
    """处理不同类型的响应格式"""
    
    @staticmethod
    def basic_response(text: str) -> str:
        """返回基本文本响应"""
        return text
    
    @staticmethod
    async def stream_response(model: BaseLLM, prompt: str, **kwargs) -> Any:
        """生成流式响应"""
        response_stream = await model.agenerate([prompt], **kwargs)
        for token in response_stream.generations[0][0].text:
            yield token
            await asyncio.sleep(0.01)
    
    @staticmethod
    def sse_response(background_tasks: BackgroundTasks, model: BaseLLM, 
                    prompt: str, **kwargs) -> EventSourceResponse:
        """返回SSE响应"""
        async def event_generator():
            async for token in ResponseHandler.stream_response(model, prompt, **kwargs):
                if await asyncio.sleep(0.01):
                    yield {"data": token}
                    
        return EventSourceResponse(event_generator())


class ContentFilter:
    """内容过滤器，检测敏感词和判断是否执行回复"""
    
    def __init__(self, sensitive_words: List[str] = None):
        self.sensitive_words = sensitive_words or []
        
    def contains_sensitive_content(self, text: str) -> bool:
        """检查文本是否包含敏感词"""
        return any(word in text.lower() for word in self.sensitive_words)
    
    def is_casual_conversation(self, text: str) -> bool:
        """判断是否是日常对话"""
        # 实现日常对话检测逻辑
        casual_markers = ["hi", "hello", "how are you", "what's up", "hey"]
        return any(marker in text.lower() for marker in casual_markers)
    
    def should_execute_reply(self, text: str) -> bool:
        """判断是否应该执行回复"""
        return not self.contains_sensitive_content(text)
    
    def should_use_rag(self, text: str) -> bool:
        """判断是否应该使用RAG"""
        # 如果不是日常对话且不包含敏感内容，使用RAG
        return not self.is_casual_conversation(text) and not self.contains_sensitive_content(text)
