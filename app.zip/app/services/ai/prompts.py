from typing import Dict, Optional
from langchain.prompts import PromptTemplate, ChatPromptTemplate
from langchain.prompts.chat import SystemMessagePromptTemplate, HumanMessagePromptTemplate

class PromptManager:
    """管理不同角色的提示词模板"""
    
    def __init__(self):
        self.role_prompts: Dict[str, Dict[str, str]] = {}
        self._initialize_default_prompts()
        
    def _initialize_default_prompts(self) -> None:
        """初始化默认提示词"""
        self.role_prompts = {
            "default": {
                "system": "You are a helpful assistant.",
                "human": "{input}"
            },
            "customer_service": {
                "system": "You are a friendly customer service representative. Help the customer with their inquiry.",
                "human": "{input}"
            },
            "technical_expert": {
                "system": "You are a technical expert. Provide detailed technical information.",
                "human": "{input}"
            }
        }
    
    def add_role_prompt(self, role_id: str, system_prompt: str, human_prompt: str = "{input}") -> None:
        """添加新的角色提示词"""
        self.role_prompts[role_id] = {
            "system": system_prompt,
            "human": human_prompt
        }
    
    def get_prompt_template(self, role_id: str = "default") -> ChatPromptTemplate:
        """获取指定角色的提示词模板"""
        if role_id not in self.role_prompts:
            role_id = "default"
            
        role_data = self.role_prompts[role_id]
        return ChatPromptTemplate.from_messages([
            SystemMessagePromptTemplate.from_template(role_data["system"]),
            HumanMessagePromptTemplate.from_template(role_data["human"])
        ])
    
    def generate_prompt(self, role_id: str, input_text: str) -> str:
        """生成完整提示词"""
        template = self.get_prompt_template(role_id)
        return template.format(input=input_text) 