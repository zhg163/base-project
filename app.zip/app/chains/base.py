from typing import Dict, Any, Optional
from langchain.chains import LLMChain
from langchain.llms.base import BaseLLM
from langchain.schema import BaseMemory
from langchain.prompts import ChatPromptTemplate
from app.services.ai.memory import MemoryManager
from app.services.ai.prompts import PromptManager
from app.services.ai.llm import ModelRegistry, ContentFilter

class BaseAIChain:
    """基础AI链，处理基本的模型调用逻辑"""
    
    def __init__(
        self,
        model_registry: ModelRegistry,
        prompt_manager: PromptManager,
        memory_manager: Optional[MemoryManager] = None,
        content_filter: Optional[ContentFilter] = None
    ):
        self.model_registry = model_registry
        self.prompt_manager = prompt_manager
        self.memory_manager = memory_manager or MemoryManager()
        self.content_filter = content_filter or ContentFilter()
        
    def _create_chain(self, model_id: str, role_id: str) -> LLMChain:
        """创建LLM链"""
        model = self.model_registry.get_model(model_id)
        prompt_template = self.prompt_manager.get_prompt_template(role_id)
        
        return LLMChain(
            llm=model,
            prompt=prompt_template,
            memory=self.memory_manager.memory,
            verbose=True
        )
    
    async def process(self, 
                     input_text: str, 
                     model_id: str = "default",
                     role_id: str = "default") -> Dict[str, Any]:
        """处理输入并返回结果"""
        # 检查是否应该执行回复
        if not self.content_filter.should_execute_reply(input_text):
            return {"result": "I cannot respond to this request."}
        
        # 创建链并执行
        chain = self._create_chain(model_id, role_id)
        result = await chain.arun(input=input_text)
        
        # 更新记忆
        self.memory_manager.add_user_message(input_text)
        self.memory_manager.add_ai_message(result)
        
        return {"result": result}
