from typing import Dict, Any, Optional, List
from langchain.chains import RetrievalQA
from langchain.llms.base import BaseLLM
from app.chains.base import BaseAIChain
from app.services.ai.llm import ModelRegistry, ContentFilter
from app.services.ai.memory import MemoryManager
from app.services.ai.prompts import PromptManager
from app.services.ai.rag import RAGService

class QAChain(BaseAIChain):
    """问答链，专门处理RAG加持的问答"""
    
    def __init__(
        self,
        model_registry: ModelRegistry,
        prompt_manager: PromptManager,
        rag_service: RAGService,
        memory_manager: Optional[MemoryManager] = None,
        content_filter: Optional[ContentFilter] = None
    ):
        super().__init__(model_registry, prompt_manager, memory_manager, content_filter)
        self.rag_service = rag_service
    
    def _create_qa_chain(self, model_id: str, role_id: str) -> RetrievalQA:
        """创建问答链"""
        model = self.model_registry.get_model(model_id)
        retriever = self.rag_service.get_retriever()
        
        return RetrievalQA.from_chain_type(
            llm=model,
            chain_type="stuff",
            retriever=retriever,
            verbose=True
        )
    
    async def process(self, 
                     input_text: str, 
                     model_id: str = "default",
                     role_id: str = "default") -> Dict[str, Any]:
        """处理问答请求并返回结果"""
        # 检查是否应该执行回复
        if not self.content_filter.should_execute_reply(input_text):
            return {"result": "I cannot respond to this request."}
        
        # 创建QA链并执行
        qa_chain = self._create_qa_chain(model_id, role_id)
        result = await qa_chain.arun(query=input_text)
        
        # 更新记忆
        self.memory_manager.add_user_message(input_text)
        self.memory_manager.add_ai_message(result)
        
        return {
            "result": result,
            "sources": self._get_source_documents(qa_chain)
        }
    
    def _get_source_documents(self, qa_chain: RetrievalQA) -> List[Dict[str, Any]]:
        """获取来源文档信息"""
        # 注意：实际实现可能需要根据langchain版本和RetrievalQA的具体实现进行调整
        if hasattr(qa_chain, "return_source_documents") and qa_chain.return_source_documents:
            sources = qa_chain.source_documents
            return [
                {
                    "content": doc.page_content,
                    "metadata": doc.metadata
                }
                for doc in sources
            ]
        return []
