from typing import Dict, Any, Optional, AsyncIterator
from fastapi import BackgroundTasks
from sse_starlette.sse import EventSourceResponse
from app.chains.base import BaseAIChain
from app.services.ai.llm import ModelRegistry, ContentFilter, ResponseHandler
from app.services.ai.memory import MemoryManager
from app.services.ai.prompts import PromptManager
from app.services.ai.rag import RAGService

class ChatChain(BaseAIChain):
    """聊天链，处理对话类请求"""
    
    def __init__(
        self,
        model_registry: ModelRegistry,
        prompt_manager: PromptManager,
        memory_manager: Optional[MemoryManager] = None,
        content_filter: Optional[ContentFilter] = None,
        rag_service: Optional[RAGService] = None
    ):
        super().__init__(model_registry, prompt_manager, memory_manager, content_filter)
        self.rag_service = rag_service
        self.response_handler = ResponseHandler()
    
    async def process(self, 
                     input_text: str, 
                     model_id: str = "default",
                     role_id: str = "default") -> Dict[str, Any]:
        """处理聊天请求并返回结果"""
        # 检查是否应该执行回复
        if not self.content_filter.should_execute_reply(input_text):
            return {"result": "I cannot respond to this request."}
        
        # 决定是否使用RAG
        use_rag = self.content_filter.should_use_rag(input_text)
        
        # 如果需要使用RAG且RAG服务可用
        if use_rag and self.rag_service:
            # 获取相关文档
            docs = await self.rag_service.retrieve_relevant_documents(input_text)
            # 将文档内容添加到提示词中
            context = "\n".join([doc.page_content for doc in docs])
            enriched_input = f"Context: {context}\n\nQuestion: {input_text}"
        else:
            enriched_input = input_text
            
        # 创建链并执行
        chain = self._create_chain(model_id, role_id)
        result = await chain.arun(input=enriched_input)
        
        # 更新记忆
        self.memory_manager.add_user_message(input_text)
        self.memory_manager.add_ai_message(result)
        
        return {"result": result}
    
    async def stream_process(self, 
                           input_text: str, 
                           model_id: str = "default",
                           role_id: str = "default") -> AsyncIterator[str]:
        """处理聊天请求并返回流式结果"""
        # 检查是否应该执行回复
        if not self.content_filter.should_execute_reply(input_text):
            yield "I cannot respond to this request."
            return
        
        # 决定是否使用RAG
        use_rag = self.content_filter.should_use_rag(input_text)
        
        # 如果需要使用RAG且RAG服务可用
        if use_rag and self.rag_service:
            # 获取相关文档
            docs = await self.rag_service.retrieve_relevant_documents(input_text)
            # 将文档内容添加到提示词中
            context = "\n".join([doc.page_content for doc in docs])
            enriched_input = f"Context: {context}\n\nQuestion: {input_text}"
        else:
            enriched_input = input_text
            
        # 获取模型并生成提示词
        model = self.model_registry.get_model(model_id)
        prompt = self.prompt_manager.generate_prompt(role_id, enriched_input)
        
        # 生成流式响应
        response_text = ""
        async for token in self.response_handler.stream_response(model, prompt):
            response_text += token
            yield token
        
        # 更新记忆
        self.memory_manager.add_user_message(input_text)
        self.memory_manager.add_ai_message(response_text)
    
    def sse_process(self, 
                   background_tasks: BackgroundTasks,
                   input_text: str, 
                   model_id: str = "default",
                   role_id: str = "default") -> EventSourceResponse:
        """处理聊天请求并返回SSE响应"""
        # 检查是否应该执行回复
        if not self.content_filter.should_execute_reply(input_text):
            return EventSourceResponse([{"data": "I cannot respond to this request."}])
        
        # 为了简化，这里不重复实现完整逻辑，实际应当包含RAG判断等
        model = self.model_registry.get_model(model_id)
        prompt = self.prompt_manager.generate_prompt(role_id, input_text)
        
        # 更新记忆 (需要在后台任务中完成)
        self.memory_manager.add_user_message(input_text)
        
        return self.response_handler.sse_response(
            background_tasks=background_tasks,
            model=model,
            prompt=prompt
        )
