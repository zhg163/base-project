#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
配置管理模块
"""

import os
from typing import Any, Dict, List, Optional
from pydantic import BaseSettings, validator, Field


class Settings(BaseSettings):
    """应用配置"""
    
    # 应用设置
    APP_NAME: str = "AI Service"
    DEBUG: bool = Field(False, env="DEBUG")
    
    # LLM设置
    OPENAI_API_KEY: str = Field("", env="OPENAI_API_KEY")
    DEFAULT_MODEL: str = "gpt-3.5-turbo"
    AVAILABLE_MODELS: Dict[str, Dict[str, Any]] = {
        "gpt-3.5-turbo": {
            "type": "openai",
            "model_name": "gpt-3.5-turbo",
            "temperature": 0.7,
            "streaming": True
        },
        "gpt-4": {
            "type": "openai",
            "model_name": "gpt-4",
            "temperature": 0.7,
            "streaming": True
        }
    }
    
    # 内容过滤设置
    SENSITIVE_WORDS: List[str] = ["inappropriate", "offensive", "illegal"]
    
    # 记忆设置
    MEMORY_TYPE: str = "buffer"  # 'buffer' or 'summary'
    MAX_TOKEN_LIMIT: int = 2000
    
    # Redis设置
    REDIS_HOST: str = Field("localhost", env="REDIS_HOST")
    REDIS_PORT: int = Field(6379, env="REDIS_PORT")
    REDIS_PASSWORD: Optional[str] = Field(None, env="REDIS_PASSWORD")
    
    # 向量数据库设置
    VECTOR_DB_TYPE: str = "FAISS"  # 'FAISS', 'Pinecone', 'Weaviate', etc.
    
    # 应用路径设置
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# 创建全局设置对象
settings = Settings()