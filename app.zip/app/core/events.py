from typing import Callable
from fastapi import FastAPI
from langchain.chat_models import ChatOpenAI
from app.core.config import settings
from app.services.ai.llm import ModelRegistry
from app.services.ai.prompts import PromptManager
from app.services.ai.memory import MemoryManager
from app.services.ai.rag import RAGService

def startup_event_handler(app: FastAPI) -> Callable:
    """应用启动事件处理器"""
    
    async def start_app() -> None:
        # 初始化模型注册表
        model_registry = ModelRegistry()
        
        # 注册所有配置的模型
        for model_id, model_config in settings.AVAILABLE_MODELS.items():
            if model_config["type"] == "openai":
                model = ChatOpenAI(
                    model_name=model_config["model_name"],
                    temperature=model_config.get("temperature", 0.7),
                    streaming=model_config.get("streaming", False),
                    openai_api_key=settings.OPENAI_API_KEY,
                    verbose=True
                )
                model_registry.register_model(model_id, model)
        
        # 保存到应用状态
        app.state.model_registry = model_registry
        
        # 初始化提示词管理器
        prompt_manager = PromptManager()
        app.state.prompt_manager = prompt_manager
        
        # 输出启动信息
        print(f"Application {settings.APP_NAME} started")
        print(f"Available models: {model_registry.list_models()}")
    
    return start_app


def shutdown_event_handler(app: FastAPI) -> Callable:
    """应用关闭事件处理器"""
    
    async def stop_app() -> None:
        # 清理资源
        print(f"Application {settings.APP_NAME} shutdown")
    
    return stop_app


def register_events(app: FastAPI) -> None:
    """注册应用事件"""
    app.add_event_handler("startup", startup_event_handler(app))
    app.add_event_handler("shutdown", shutdown_event_handler(app))
