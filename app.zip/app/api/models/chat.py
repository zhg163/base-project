from typing import Optional, List, Dict, Any
from pydantic import BaseModel

class ChatRequest(BaseModel):
    """聊天请求模型"""
    message: str
    model_id: str = "default"
    role_id: str = "default"
    session_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class ChatResponse(BaseModel):
    """聊天响应模型"""
    message: str
    sources: Optional[List[Dict[str, Any]]] = None 