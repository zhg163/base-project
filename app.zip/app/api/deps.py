from typing import Optional
from fastapi import Depends
from app.chains.chat import ChatChain
from app.chains.qa import QAChain
from app.services.ai.llm import ModelRegistry, ContentFilter
from app.services.ai.memory import MemoryManager
from app.services.ai.prompts import PromptManager
from app.services.ai.rag import RAGService
from app.services.storage.redis_service import RedisService

# 单例对象
model_registry = ModelRegistry()
prompt_manager = PromptManager()
content_filter = ContentFilter()

# 依赖注入函数
def get_memory_manager(session_id: Optional[str] = None) -> MemoryManager:
    """获取记忆管理器实例"""
    return MemoryManager(memory_type="buffer")

def get_redis_service() -> RedisService:
    """获取Redis服务实例"""
    # 实际实现应从配置中获取连接信息
    return RedisService(host="localhost", port=6379)

def get_rag_service(redis_service: RedisService = Depends(get_redis_service)) -> RAGService:
    """获取RAG服务实例"""
    # 实际实现应从配置和服务获取向量存储和嵌入模型
    # 此处为简化示例
    from langchain.vectorstores import FAISS
    from langchain.embeddings import OpenAIEmbeddings
    
    embeddings = OpenAIEmbeddings()
    vector_store = FAISS.from_texts(
        ["example document"], embeddings=embeddings
    )
    
    return RAGService(vector_store=vector_store, embeddings=embeddings)

def get_chat_chain(
    memory_manager: MemoryManager = Depends(get_memory_manager),
    rag_service: RAGService = Depends(get_rag_service)
) -> ChatChain:
    """获取聊天链实例"""
    return ChatChain(
        model_registry=model_registry,
        prompt_manager=prompt_manager,
        memory_manager=memory_manager,
        content_filter=content_filter,
        rag_service=rag_service
    )

def get_qa_chain(
    memory_manager: MemoryManager = Depends(get_memory_manager),
    rag_service: RAGService = Depends(get_rag_service)
) -> QAChain:
    """获取问答链实例"""
    return QAChain(
        model_registry=model_registry,
        prompt_manager=prompt_manager,
        rag_service=rag_service,
        memory_manager=memory_manager,
        content_filter=content_filter
    )
