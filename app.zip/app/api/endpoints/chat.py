from typing import Dict, Any, List
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
from sse_starlette.sse import EventSourceResponse
from app.api.models.chat import ChatRequest, ChatResponse
from app.chains.chat import ChatChain
from app.api.deps import get_chat_chain

router = APIRouter()

@router.post("/chat", response_model=ChatResponse)
async def create_chat(
    request: ChatRequest,
    chat_chain: ChatChain = Depends(get_chat_chain)
) -> Dict[str, Any]:
    """创建普通聊天响应"""
    try:
        response = await chat_chain.process(
            input_text=request.message,
            model_id=request.model_id,
            role_id=request.role_id
        )
        return {"message": response["result"]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/stream")
async def create_stream_chat(
    request: ChatRequest,
    chat_chain: ChatChain = Depends(get_chat_chain)
):
    """创建流式聊天响应"""
    try:
        return await chat_chain.stream_process(
            input_text=request.message,
            model_id=request.model_id,
            role_id=request.role_id
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat/sse")
async def create_sse_chat(
    request: ChatRequest,
    background_tasks: BackgroundTasks,
    chat_chain: ChatChain = Depends(get_chat_chain)
):
    """创建SSE聊天响应"""
    try:
        return chat_chain.sse_process(
            background_tasks=background_tasks,
            input_text=request.message,
            model_id=request.model_id,
            role_id=request.role_id
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 